// using for e2e local test --> see angular.json

export const environment = {
  production: false
};
