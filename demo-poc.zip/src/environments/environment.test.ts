export const environment = {
  production: true,
  test: true
};
