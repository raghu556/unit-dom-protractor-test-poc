## Getting Started

This project was generated with Angular CLI version 7.3.7.

## Prerequisites

In order to install and run the project you need to have the following software already installed on your machine:

1. [Node.js v10.x](https://nodejs.org/dist/latest-v10.x/)
2. [Angular CLI](https://cli.angular.io/)
3. [Google Chrome](https://www.google.com/chrome/)
4. In order to have backend connectivity and database for the application please set up in accordance with the instructions given in [README.md](../backend/README.md) for backend

## Installation

1. Open project folder [demo-poc](.) in a command prompt and run following command to install project dependencies:

```
npm install
```
## Building, Testing and Running

### Build

To build the frontend for deployment, run `npm build:prod`. The build artifacts will be generated in the `dist/` directory.

### Running jasmine unit tests and CDCT

To execute the tests and consumer part of CDCT, in a command prompt run:
 ```
 npm test
 ```

#### Configuration

- [karma.conf.js](karma.conf.js)

### Running the Headless tests

To run the headless tests locally in a development environment run 
```
npm e2e:local
```

Note that the backend needs to run locally as explained in the backend [README.md](../backend/README.md).

To run the headless test against a deployed version of the frontend run
```
npm e2e:prod -- --baseUrl=<url path to fronend>
```

The `<url path to fronend>` is the url path of the web-server that serves the frontend e.g `npm e2e:prod -- --baseUrl=http://some-server:8080/web/`

### Running application

To start the front end for a local development web server, run `npm start`. Note that the backend needs to run locally as explained in the [Configuration](#cfg) section.

```
npm start
```

Navigate to `http://localhost:4200/`.

## Developing

### Visual Studio Code

#### extensions

- Debugger for Chrome
- Prettier - Code formatter

#### style

We try to format the code in the same way - therefore a tslint is configure to proof formatting and support the prettier extension to autoformat the code.

- MUST: tslint in prettier shall be activated - "Settings" - "Extensions" - "Prettier - Code formatter" - "TSLint integration" : True
- INFO: shortcut "SHIFT-ALT-F" will format a document (or ask for the default formatter if none is defined)
- COULD: format on save can be enabled in "Settings" - "Text Editor" - "Formatting" - "Format On Save"

### IntelliJ IDEA

#### extensions (via Settings - Plugins)

- Prettier

#### style

- configuration
  - open [./tslint.json]
  - click "Apply TSLint Code Style Rules" from the context menu - see [here](https://www.jetbrains.com/help/idea/using-tslint-code-quality-tool.html#ws_tslint_import_code_style)
- use CTRL+ALT+L to format actual file
- use CTRL+ALT+SHIFT+L to format actual file with configuration dialog
- OPTIONAL: check sanitize options in commit dialog

## Links, Literature and Reading

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).
