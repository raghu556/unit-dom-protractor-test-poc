import { Component } from '@angular/core';

@Component({
   selector: 'app-root',
   templateUrl: './app.component.html',
   styleUrls: ['./app.component.css']
})
export class AppComponent {
   spinnerValue;
   spinnerInitialValue;

   // Emited from spinnerInitialSetValueOut Output
   initialSpinnerEmitOutValue(event) {
      this.spinnerInitialValue = event;
   }

   // Emited from spinnerValueOut Output
   onChangedSpinnerEmitOutValue(event) {
      this.spinnerValue = event;
   }
}
