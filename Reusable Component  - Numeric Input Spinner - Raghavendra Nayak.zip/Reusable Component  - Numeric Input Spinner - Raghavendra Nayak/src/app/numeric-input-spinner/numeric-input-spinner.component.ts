import { Component, OnInit, Input, Output, forwardRef, EventEmitter, OnChanges } from '@angular/core';
import {
   FormBuilder, FormControl, FormGroup, Validators,
   AbstractControl, ControlValueAccessor, NG_VALUE_ACCESSOR, NG_VALIDATORS
} from '@angular/forms';

/*Range Validation Method*/
export function createCounterRangeValidator(maxValue, minValue) {
   return (c: FormControl) => {
      const err = {
         rangeError: {
            given: c.value,
            max: maxValue || 100,
            min: minValue || 1
         }
      };

      return (c.value > +maxValue || c.value < +minValue) ? err : null;
   }
}

@Component({
   selector: 'app-numeric-input-spinner',
   templateUrl: './numeric-input-spinner.component.html',
   styleUrls: ['./numeric-input-spinner.component.css'],
   providers: [
      { provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => NumericInputSpinnerComponent), multi: true },
      { provide: NG_VALIDATORS, useExisting: forwardRef(() => NumericInputSpinnerComponent), multi: true }
   ]
})
export class NumericInputSpinnerComponent implements OnInit {
   @Input() min;
   @Input() max;
   @Input() value;
   @Input() step;
   @Input() maxlength;
   @Output() spinnerValueOut: EventEmitter<any> = new EventEmitter<any>();
   @Output() spinnerInitialSetValueOut: EventEmitter<any> = new EventEmitter<any>();
   spinnerInput;

   /* Inteface Varaibles from ControlValueAccessor which is needed for Form Group Validation*/
   propagateChange: any = () => { };
   validateFn: any = () => { };
   onTouched: any = () => { };
   /**********************************/

   constructor() { }

   ngOnInit() {
      this.spinnerInput = this.value; // setting the default Value    
      this.spinnerInitialSetValueOut.emit(this.spinnerInput);
      this.spinnerValueOut.emit(this.spinnerInput);
   }

   /* Inteface Methods from ControlValueAccessor which is needed for Form Group Validation*/
   writeValue(value: any) {
      this.value = value;
      this.spinnerInput = value;
   }
   registerOnChange(fn) {
      this.propagateChange = fn;
   }
   registerOnTouched(fn) {
      this.onTouched = fn;
   }
   validate(c: FormControl) {
      return this.validateFn(c);
   }
   /**********************************/

   ngOnChanges(changeValue) {
      this.validateFn = createCounterRangeValidator(this.max, this.min);
      this.spinnerInput = this.value; // setting the changed Value
      this.propagateChange(this.spinnerInput);
   }

   onkeyUp(event) {
      if (this.spinnerInput > this.max) {
         this.spinnerInput = this.min;
      }
      this.spinnerValueOut.emit(this.spinnerInput); // Emiting Out the Spinner Value 
      this.propagateChange(this.spinnerInput);
      this.onTouched();
   }

   onKeyPress(event) {
      const pattern = /[0-9\+\-\ ]/;
      let inputChar = String.fromCharCode(event.charCode);
      if (event.keyCode != 8 && !pattern.test(inputChar)) {
         event.preventDefault();
      }

   }

   increement() {
      (this.spinnerInput < this.max)
         ? this.spinnerInput = this.spinnerInput + this.step
         : this.spinnerInput = this.spinnerInput;

      this.spinnerValueOut.emit(this.spinnerInput); // Emiting Out the Spinner Value 
      this.propagateChange(this.spinnerInput);
      this.onTouched();
   }

   decreement() {
      (this.spinnerInput > this.min)
         ? this.spinnerInput = this.spinnerInput - this.step
         : this.spinnerInput = this.spinnerInput;

      this.spinnerValueOut.emit(this.spinnerInput); // Emiting Out the Spinner Value 
      this.propagateChange(this.spinnerInput);
      this.onTouched();
   }
}
