import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NumericInputSpinnerComponent } from './numeric-input-spinner.component';

describe('NumericInputSpinnerComponent', () => {
  let component: NumericInputSpinnerComponent;
  let fixture: ComponentFixture<NumericInputSpinnerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NumericInputSpinnerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NumericInputSpinnerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
