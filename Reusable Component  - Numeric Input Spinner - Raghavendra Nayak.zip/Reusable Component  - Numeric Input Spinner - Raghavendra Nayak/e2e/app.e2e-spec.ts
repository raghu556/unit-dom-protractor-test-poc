import { NumericInputSpinnerPage } from './app.po';

describe('numeric-input-spinner App', () => {
  let page: NumericInputSpinnerPage;

  beforeEach(() => {
    page = new NumericInputSpinnerPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!');
  });
});
