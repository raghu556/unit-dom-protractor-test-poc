import {
   Component, OnInit, OnDestroy, Input, Output,
   forwardRef, EventEmitter,
   HostListener, ElementRef, ChangeDetectionStrategy, ChangeDetectorRef
} from '@angular/core';
import {
   FormBuilder, FormControl, FormGroup, Validators,
   AbstractControl, ControlValueAccessor, NG_VALUE_ACCESSOR, NG_VALIDATORS
} from '@angular/forms';

@Component({
   selector: 'app-time-picker',
   templateUrl: './time-picker.component.html',
   styleUrls: ['./time-picker.component.scss'],
   providers: [
      { provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => OdTimePickerComponent), multi: true },
      { provide: NG_VALIDATORS, useExisting: forwardRef(() => OdTimePickerComponent), multi: true }]
})

export class OdTimePickerComponent implements OnInit {
   propagateChange: any = () => { };
   validateFn: any = () => { };
   onTouched: any = () => { };
   @Input() value;
   @Output() timeValueOut: EventEmitter<any> = new EventEmitter<any>();

   insideTimePickerComponent = false; //Boolean to indicate click is inside the component
   hoursOption = [];
   minutesOptions = [];
   secondsOptions = [];
   timeHrBuffer = {};
   timeMinBuffer = {};
   timeSecBuffer = {};
   showTimePickerDropdown = false;
   timeValue = "00:00:00";
   constructor(private eRef: ElementRef) { }
   writeValue(value: any) { }
   registerOnChange(fn) {
      this.propagateChange = fn;
   }
   registerOnTouched(fn) {
      this.onTouched = fn;
   }
   validate(c: FormControl) {
      return this.validateFn(c);
   }

   ngOnInit() {
      this.hoursOption = this.numberArrayGeneration(0, 23, 1, 'H');
      this.minutesOptions = this.numberArrayGeneration(0, 55, 5, 'M');
      this.secondsOptions = this.numberArrayGeneration(0, 55, 5, 'S');
      if (this.value) {
         let tempArr = this.value.split(":");
         if (tempArr.length == 3) {
            this.timeValue = tempArr[0] + ":" + tempArr[1] + ":" + tempArr[2];
         }
      }
      this.timeValueOut.emit(this.timeValue);
   }

   setTime(value, timeType, index) {
      this.insideTimePickerComponent = true; //Boolean to indicate click is inside the component
      if (value < 10) {
         value = "0" + value;
      }
      if (timeType == 'H') {
         this.timeValue = value + ":" + this.timeValue.split(":")[1] + ":" + this.timeValue.split(":")[2]
         this.timeHrBuffer = {};
         this.timeHrBuffer[Number(value)] = !this.timeHrBuffer[Number(value)];
      } else if (timeType == 'M') {
         this.timeValue = this.timeValue.split(":")[0] + ":" + value + ":" + this.timeValue.split(":")[2];
         // this.timeValue.split(":")[1] = value;
         this.timeMinBuffer = {};
         this.timeMinBuffer[Number(value)] = !this.timeMinBuffer[Number(value)];
      } else if (timeType == 'S') {
         this.timeValue = this.timeValue.split(":")[0] + ":" + this.timeValue.split(":")[1] + ":" + value
         // this.timeValue.split(":")[2] = value;
         this.timeSecBuffer = {};
         this.timeSecBuffer[Number(value)] = !this.timeSecBuffer[Number(value)];
      }
      this.timeValueOut.emit(this.timeValue);
   }
   openTimeDropdown() {
      this.showTimePickerDropdown = true;
      this.insideTimePickerComponent = true; //Boolean to indicate click is inside the component
      this.timeHrBuffer[Number(this.timeValue.split(":")[0])] = true;
      this.timeMinBuffer[Number(this.timeValue.split(":")[1])] = true;
      this.timeSecBuffer[Number(this.timeValue.split(":")[2])] = true;
   }

   numberArrayGeneration(startValue, endValue, step, type) {
      const arrValue = [];
      let stepValue = startValue;
      arrValue.push(startValue);
      for (let i = stepValue; i <= endValue; i++) {
         stepValue = stepValue + step;
         i = stepValue;
         arrValue.push(stepValue);
         if (type == 'H') {
            this.timeHrBuffer[stepValue] = false;
         } else if (type == 'M') {
            this.timeMinBuffer[stepValue] = false;
         } else if (type == 'S') {
            this.timeSecBuffer[stepValue] = false;
         }
      }
      return arrValue;
   }

   @HostListener('document:click', ['$event'])
   onDocumentClick(e) {
      let nativeElement = false;
      if (this.eRef.nativeElement.contains(e.target) && this.insideTimePickerComponent) {
         nativeElement = true;
         this.insideTimePickerComponent = false; //Boolean to indicate click is inside the component
      }
      if (!nativeElement) {
         this.showTimePickerDropdown = false;
      }
   }
}
