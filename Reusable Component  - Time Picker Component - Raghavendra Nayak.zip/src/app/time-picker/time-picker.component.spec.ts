import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OdTimePickerComponent } from './od-time-picker.component';

describe('OdTimePickerComponent', () => {
  let component: OdTimePickerComponent;
  let fixture: ComponentFixture<OdTimePickerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OdTimePickerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OdTimePickerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
