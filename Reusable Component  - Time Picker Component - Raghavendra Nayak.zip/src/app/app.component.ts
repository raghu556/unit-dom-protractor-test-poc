import { Component } from '@angular/core';

@Component({
   selector: 'app-root',
   templateUrl: './app.component.html',
   styleUrls: ['./app.component.css']
})
export class AppComponent {
   timeValue;
   hrs;
   min;
   sec;
   // Emited from Time Picker Output
   timeValueOutEmitted(event) {
      this.timeValue = event;
      this.hrs = this.timeValue.split(':')[0];
      this.min = this.timeValue.split(':')[1];
      this.sec = this.timeValue.split(':')[2];
   }
}
